const colors = {
    'white' : '#ffff'
}
export default colors;